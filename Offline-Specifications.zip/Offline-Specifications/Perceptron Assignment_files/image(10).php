<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [
	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">
]>
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="24px" height="24px" viewBox="-0.1 -2 24 24"
	 style="overflow:visible;enable-background:new -0.1 -2 24 24;" xml:space="preserve" preserveAspectRatio="xMinYMid meet">
<defs>
</defs>
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="11.9351" y1="0" x2="11.9351" y2="20.0005">
	<stop  offset="0" style="stop-color:#76A1F0"/>
	<stop  offset="1" style="stop-color:#6B90D5"/>
	<a:midPointStop  offset="0" style="stop-color:#76A1F0"/>
	<a:midPointStop  offset="0.5" style="stop-color:#76A1F0"/>
	<a:midPointStop  offset="1" style="stop-color:#6B90D5"/>
</linearGradient>
<path style="fill:url(#SVGID_1_);" d="M21.9,19c0,0.5-0.5,1-1,1h-18c-0.5,0-1-0.5-1-1V1.1c0-0.5,0.5-1.1,1-1.1h4
	c0.5,0,1.4,0.3,1.8,0.6l0.9,0.7C10.1,1.7,10.9,2,11.4,2l9.5,0c0.5,0,1,0.5,1,1V19z"/>
<linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="11.9351" y1="0.9888" x2="11.9351" y2="19.0005">
	<stop  offset="0" style="stop-color:#BBE0F7"/>
	<stop  offset="1" style="stop-color:#82B4FB"/>
	<a:midPointStop  offset="0" style="stop-color:#BBE0F7"/>
	<a:midPointStop  offset="0.5" style="stop-color:#BBE0F7"/>
	<a:midPointStop  offset="1" style="stop-color:#82B4FB"/>
</linearGradient>
<path style="fill:url(#SVGID_2_);" d="M2.9,19V1.1C2.9,1.1,3,1,3,1l3.9,0c0.3,0,0.9,0.2,1.2,0.4L9,2.2C9.7,2.6,10.7,3,11.4,3l9.5,0
	v16H2.9z"/>
<linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="11.9351" y1="1.9917" x2="11.9351" y2="18.0005">
	<stop  offset="0" style="stop-color:#95BFF8"/>
	<stop  offset="0.5569" style="stop-color:#84ADEF"/>
	<stop  offset="1" style="stop-color:#7CA4EB"/>
	<a:midPointStop  offset="0" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="0.4" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="1" style="stop-color:#7CA4EB"/>
</linearGradient>
<path style="fill:url(#SVGID_3_);" d="M3.9,18V2l3,0C7,2,7.4,2.1,7.5,2.2L8.4,3c0.8,0.6,2.1,1,3,1l8.5,0v14H3.9z"/>
<linearGradient id="SVGID_4_" gradientUnits="userSpaceOnUse" x1="11.936" y1="5" x2="11.936" y2="20.0005">
	<stop  offset="0" style="stop-color:#76A1F0"/>
	<stop  offset="1" style="stop-color:#6B90D5"/>
	<a:midPointStop  offset="0" style="stop-color:#76A1F0"/>
	<a:midPointStop  offset="0.5" style="stop-color:#76A1F0"/>
	<a:midPointStop  offset="1" style="stop-color:#6B90D5"/>
</linearGradient>
<path style="fill:url(#SVGID_4_);" d="M23,19c0,0.5-0.5,1-1.1,1h-20c-0.5,0-1-0.5-1.1-1L0,6c0-0.5,0.4-1,0.9-1h22c0.5,0,1,0.5,0.9,1
	L23,19z"/>
<linearGradient id="SVGID_5_" gradientUnits="userSpaceOnUse" x1="11.9673" y1="5.9541" x2="11.9673" y2="19.0005">
	<stop  offset="0" style="stop-color:#BBE0F7"/>
	<stop  offset="1" style="stop-color:#82B4FB"/>
	<a:midPointStop  offset="0" style="stop-color:#BBE0F7"/>
	<a:midPointStop  offset="0.5" style="stop-color:#BBE0F7"/>
	<a:midPointStop  offset="1" style="stop-color:#82B4FB"/>
</linearGradient>
<path style="fill:url(#SVGID_5_);" d="M1.9,19c0,0-0.1-0.1-0.1-0.1L1,6l21.9,0L22,18.9c0,0,0,0.1-0.1,0.1H1.9z"/>
<linearGradient id="SVGID_6_" gradientUnits="userSpaceOnUse" x1="11.9663" y1="6.9565" x2="11.9663" y2="18.0005">
	<stop  offset="0" style="stop-color:#95BFF8"/>
	<stop  offset="0.5569" style="stop-color:#84ADEF"/>
	<stop  offset="1" style="stop-color:#7CA4EB"/>
	<a:midPointStop  offset="0" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="0.4" style="stop-color:#95BFF8"/>
	<a:midPointStop  offset="1" style="stop-color:#7CA4EB"/>
</linearGradient>
<polygon style="fill:url(#SVGID_6_);" points="2.8,18 2.1,7 21.9,7 21.1,18 "/>
</svg>
