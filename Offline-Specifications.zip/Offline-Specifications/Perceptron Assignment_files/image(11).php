<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 15.1.0, SVG Export Plug-In  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd" [
	<!ENTITY ns_flows "http://ns.adobe.com/Flows/1.0/">
]>
<svg version="1.1"
	 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
	 x="0px" y="0px" width="16px" height="16px" viewBox="0 0 16 16" style="overflow:visible;enable-background:new 0 0 16 16;"
	 xml:space="preserve" preserveAspectRatio="xMinYMid meet">
<defs>
</defs>
<path style="fill:#999999;" d="M15,0H1C0.5,0,0,0.5,0,1v14c0,0.5,0.5,1,1,1h14c0.5,0,1-0.5,1-1V1C16,0.5,15.5,0,15,0z M8,14H2v-2h6
	V14z M8,11H2V9h6V11z M8,8H2V6h6V8z M11,14H9v-2h2V14z M11,11H9V9h2V11z M11,8H9V6h2V8z M14,14h-2v-2h2V14z M14,11h-2V9h2V11z M14,8
	h-2V6h2V8z"/>
</svg>
